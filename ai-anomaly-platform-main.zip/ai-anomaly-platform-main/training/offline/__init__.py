"""Offline training workflows."""
